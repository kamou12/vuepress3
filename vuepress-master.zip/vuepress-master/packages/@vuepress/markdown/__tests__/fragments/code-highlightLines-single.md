``` js {1}
new Vue()
```
