``` js
new Vue()
```
