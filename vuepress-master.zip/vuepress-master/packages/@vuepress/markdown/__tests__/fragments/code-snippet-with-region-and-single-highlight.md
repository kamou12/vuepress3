<<< @/packages/@vuepress/markdown/__tests__/fragments/snippet-with-region.js#snippet{11}
