# @vuepress/theme-vue

> theme-vue for VuePress
