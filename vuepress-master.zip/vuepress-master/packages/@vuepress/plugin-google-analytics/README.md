# @vuepress/plugin-google-analytics

> Google analytics plugin for VuePress

See [documentation](https://v1.vuepress.vuejs.org/plugin/official/plugin-google-analytics.html).
