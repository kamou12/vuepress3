# @vuepress/plugin-last-updated

> last-updated plugin for VuePress

See [documentation](https://v1.vuepress.vuejs.org/plugin/official/plugin-last-updated.html).
