import BackToTop from './BackToTop.vue'

export default ({ Vue }) => {
  // eslint-disable-next-line vue/match-component-file-name
  Vue.component('BackToTop', BackToTop)
}
