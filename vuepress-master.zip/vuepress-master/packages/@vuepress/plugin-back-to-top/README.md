# @vuepress/plugin-back-to-top

> Back-to-top plugin for VuePress

See [documentation](https://v1.vuepress.vuejs.org/plugin/official/plugin-back-to-top.html).
