# @vuepress/core

## APIs

### dev(sourceDir, options)

### build(sourceDir, options)

### eject(targetDir)
