<template>
  <Content />
</template>
