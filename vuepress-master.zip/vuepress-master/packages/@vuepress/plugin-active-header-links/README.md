# @vuepress/plugin-active-header-links

> active-header-links plugin for VuePress

See [documentation](https://v1.vuepress.vuejs.org/plugin/official/plugin-active-header-links.html).
