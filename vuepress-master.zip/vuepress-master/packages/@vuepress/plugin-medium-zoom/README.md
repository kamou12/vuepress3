# @vuepress/plugin-medium-zoom

> medium-zoom plugin for VuePress

See [documentation](https://v1.vuepress.vuejs.org/plugin/official/plugin-medium-zoom.html).
