# @vuepress/plugin-search

> header-based search plugin for VuePress

See [documentation](https://v1.vuepress.vuejs.org/plugin/official/plugin-search.html).

