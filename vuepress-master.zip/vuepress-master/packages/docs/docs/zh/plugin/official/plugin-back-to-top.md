---
title: back-to-top
metaTitle: Back-To-Top 插件 | VuePress
---

# [@vuepress/plugin-back-to-top](https://github.com/vuejs/vuepress/tree/master/packages/@vuepress/plugin-back-to-top)

> back-to-top 插件.

## 安装

```bash
yarn add -D @vuepress/plugin-back-to-top
# OR npm install -D @vuepress/plugin-back-to-top
```

## 使用

```javascript
module.exports = {
  plugins: ['@vuepress/back-to-top']
}
```
